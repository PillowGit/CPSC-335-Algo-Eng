# How to run

### To see the output of the lawnmower algorithm:

1. Use the python command to run `lawnmower.py`

If running on windows, this command will just be `python`, not `python3`

```bash
python3 lawnmower.py
```


### To see the output of the left-to-right algorithm:

1. Use the python command to run `left_to_right.py`

If running on windows, this command will just be `python`, not `python3`

```bash
python3 left_to_right.py
```

